XML Edit is a file type plugin to help edit XML documents.
It includes tag completion and tag jumping.

To install this package. Expand or copy these directories to your VIM home. On
Unix systems this is ~/.vim On MS-DOS it is your $VIM/vimfiles folder.

On a Unix system, if you wish to make this script avaliable system wide place
this package into your $VIMRUNTIME directory.

Once this is done build the documentaion links by running the VIM command
    ':helptags <INSTALL_DIR>/doc'
Where <INSTALL_DIR> is the directory you expanded or copied the package to.
(See |:helptags| for details.)

Now read doc/xml-plugin.txt or type ':help xml-plugin.txt' in VIM.
